﻿using Npgsql;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Text;
using Telegram.Bot.Types;

namespace bbQuiz
{
    internal class ChatSettings
    {
        internal static ConcurrentDictionary<long, int> TimeBetweenHints = new();
        internal static ConcurrentDictionary<long, int> SkipsNeed = new();
        internal static ConcurrentDictionary<long, long> isChatBeingConfigured = new();
        internal static ConcurrentDictionary<long, string> whichSettingChanging = new();
        internal static ConcurrentDictionary<long, SemaphoreSlim> semaphores = new();

        internal static async Task StartSettingsTimer(long chatId, long userId, int seconds)
        {
            isChatBeingConfigured[chatId] = userId;
            semaphores[chatId] = new SemaphoreSlim(1, 1);
            await Task.Delay(seconds * 1000);
            _ = Task.Run(() => CancelSettings(chatId));
        }
        internal async static Task CancelSettings(long chatId)
        {
            lock (semaphores[chatId])
            {
                isChatBeingConfigured.TryRemove(chatId, out _);
                whichSettingChanging.TryRemove(chatId, out _);
                semaphores.TryRemove(chatId, out var _);
            }
        }
        internal async static Task<int> GetSkipsNeed(long chatId)
        {
            lock (semaphores[chatId])
            {
                if (SkipsNeed.TryGetValue(chatId, out var value)) return value;
            }

            using var conn = new NpgsqlConnection(BotData.connString);
            await conn.OpenAsync();

            string sql = "SELECT * FROM chatsettings WHERE chat_id = @chatId";

            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("chatId", chatId);

            using var reader = await cmd.ExecuteReaderAsync();

            if (await reader.ReadAsync())
            {
                return (int)reader["skips_needed"];
            }
            else
            {
                SetSkipsNeed(chatId, 2);
                return 2;
            }
        }
        internal async static Task SetSkipsNeed(long chatId, int value)
        {
            lock (semaphores[chatId])
            {
                SkipsNeed[chatId] = value;
            }

            using var conn = new NpgsqlConnection(BotData.connString);
            await conn.OpenAsync();

            string sql = @"
            INSERT INTO chatsettings (chat_id, skips_needed)
            VALUES (@chatId, @value)
            ON CONFLICT (chat_id)
            DO UPDATE SET skips_needed = EXCLUDED.skips_needed";

            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("chatId", chatId);
            cmd.Parameters.AddWithValue("value", value);
            await cmd.ExecuteNonQueryAsync();
        }

        internal async static Task<int> GetTimeBetweenHints(long chatId)
        {
            lock (semaphores[chatId])
            {
                if (TimeBetweenHints.TryGetValue(chatId, out var value)) return value;
            }

            using var conn = new NpgsqlConnection(BotData.connString);
            await conn.OpenAsync();

            string sql = "SELECT * FROM chatsettings WHERE chat_id = @chatId";

            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("chatId", chatId);

            using var reader = await cmd.ExecuteReaderAsync();

            if (await reader.ReadAsync())
            {
                return (int)reader["time_between_hints"];
            }
            else
            {
                await SetTimeBetweenHints(chatId, 7);
                return 7;
            }
        }
        internal async static Task SetTimeBetweenHints(long chatId, int value)
        {
            lock (semaphores[chatId])
            {
                TimeBetweenHints[chatId] = value;
            }

            using var conn = new NpgsqlConnection(BotData.connString);
            await conn.OpenAsync();

            string sql = @"
            INSERT INTO chatsettings (chat_id, time_between_hints)
            VALUES (@chatId, @value)
            ON CONFLICT (chat_id)
            DO UPDATE SET time_between_hints = EXCLUDED.time_between_hints";

            using var cmd = new NpgsqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("chatId", chatId);
            cmd.Parameters.AddWithValue("value", value);
            await cmd.ExecuteNonQueryAsync();
        }
    }
}
